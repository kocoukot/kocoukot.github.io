var showhelp_var = "sec_player_showhelp";
var completed_var = "sec_player_completed";
var store_var = "sec_player_store";