var showhelp_var = "with_zoom_showhelp_112";
var completed_var = "with_zoom_completed_112";
var store_var = "with_zoom_store_112";