var showhelp_var = "dnd_task_showhelp";
var completed_var = "dnd_task_completed";
var store_var = "dnd_task_store";