var showhelp_var = "with_zoom_showhelp_120";
var completed_var = "with_zoom_completed_120";
var store_var = "with_zoom_store_120";