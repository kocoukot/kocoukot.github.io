var showhelp_var = "dnd_two_with_zoom_showhelp";
var completed_var = "dnd_two_with_zoom_completed";
var store_var = "dnd_two_with_zoom_store";