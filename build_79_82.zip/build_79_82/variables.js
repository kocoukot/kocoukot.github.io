var showhelp_var = "dnd_task_showhelp_79_82";
var completed_var = "dnd_task_completed_79_82";
var store_var = "dnd_task_store_79_82";