var showhelp_var = "player_task_showhelp_atom";
var completed_var = "player_task_completed_atom";
var store_var = "player_task_store_atom";