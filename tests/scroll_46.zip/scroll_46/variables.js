var showhelp_var = "scrolling_showhelp_scroll_46";
var completed_var = "scrolling_completed_scroll_46";
var store_var = "scrolling_store_scroll_46";