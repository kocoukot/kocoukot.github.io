var showhelp_var = "115_showhelp";
var completed_var = "115_completed";
var store_var = "115_store";