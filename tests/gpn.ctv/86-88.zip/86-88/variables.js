var showhelp_var = "dnd_task_showhelp_86";
var completed_var = "dnd_task_completed_86";
var store_var = "dnd_task_store_86";