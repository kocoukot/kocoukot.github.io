var showhelp_var = "dnd_two_with_zoom_showhelp_dnd_zoom";
var completed_var = "dnd_two_with_zoom_completed_dnd_zoom";
var store_var = "dnd_two_with_zoom_store_dnd_zoom";