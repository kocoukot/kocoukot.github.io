var showhelp_var = "dnd_task_showhelp_90";
var completed_var = "dnd_task_completed_90";
var store_var = "dnd_task_store_90";