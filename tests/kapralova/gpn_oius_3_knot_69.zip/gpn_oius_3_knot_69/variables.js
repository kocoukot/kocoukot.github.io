var showhelp_var = "knots_showhelp_knot_69";
var completed_var = "knots_completed_knot_69";
var store_var = "knots_store_knot_69";