var showhelp_var = "view_with_scroll_showhelp";
var completed_var = "view_with_scroll_completed";
var store_var = "view_with_scroll_store";