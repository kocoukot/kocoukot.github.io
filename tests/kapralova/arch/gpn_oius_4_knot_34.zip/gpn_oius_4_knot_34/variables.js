var showhelp_var = "knots_showhelp_34";
var completed_var = "knots_completed_34";
var store_var = "knots_store_34";