var showhelp_var = "player_task_showhelp";
var completed_var = "player_task_completed";
var store_var = "player_task_store";