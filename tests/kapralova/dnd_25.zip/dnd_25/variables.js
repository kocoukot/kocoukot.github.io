var showhelp_var = "dnd_task_showhelp_dnd_25";
var completed_var = "dnd_task_completed_dnd_25";
var store_var = "dnd_task_store_dnd_25";