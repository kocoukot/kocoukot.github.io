var showhelp_var = "knots_showhelp_108";
var completed_var = "knots_completed_108";
var store_var = "knots_store_108";