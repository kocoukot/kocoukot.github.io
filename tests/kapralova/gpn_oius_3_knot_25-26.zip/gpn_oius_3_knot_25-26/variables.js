var showhelp_var = "knots_showhelp_knot_25";
var completed_var = "knots_completed_knot_25";
var store_var = "knots_store_knot_25";