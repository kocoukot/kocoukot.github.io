var showhelp_var = "task_25_knot_showhelp";
var completed_var = "task_25_knot_completed";
var store_var = "task_25_knot_store";