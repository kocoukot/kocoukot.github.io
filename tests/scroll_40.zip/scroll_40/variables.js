var showhelp_var = "scrolling_showhelp_scroll_40";
var completed_var = "scrolling_completed_scroll_40";
var store_var = "scrolling_store_scroll_40";