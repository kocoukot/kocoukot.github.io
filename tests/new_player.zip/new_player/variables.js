var showhelp_var = "player_task_showhelp_player_task";
var completed_var = "player_task_completed_player_task";
var store_var = "player_task_store_player_task";