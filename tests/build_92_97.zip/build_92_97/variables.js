var showhelp_var = "dnd_two_with_zoom_showhelp_92_97";
var completed_var = "dnd_two_with_zoom_completed_92_97";
var store_var = "dnd_two_with_zoom_store_92_97";