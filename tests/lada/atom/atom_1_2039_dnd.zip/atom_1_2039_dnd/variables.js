var showhelp_var = "task_1_2031_dnd_showhelp";
var completed_var = "task_1_2031_dnd_completed";
var store_var = "task_1_2031_dnd_store";