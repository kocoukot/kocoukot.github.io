var showhelp_var = "task_3_113_dnd_showhelp";
var completed_var = "task_3_113_dnd_completed";
var store_var = "task_3_113_dnd_store";