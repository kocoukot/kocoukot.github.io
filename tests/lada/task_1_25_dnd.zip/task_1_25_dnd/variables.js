var showhelp_var = "task_1_25_dnd_showhelp_1_25";
var completed_var = "task_1_25_dnd_completed_1_25";
var store_var = "task_1_25_dnd_store_1_25";