var showhelp_var = "task_1_25_dnd+_showhelp_1_25";
var completed_var = "task_1_25_dnd+_completed_1_25";
var store_var = "task_1_25_dnd+_store_1_25";