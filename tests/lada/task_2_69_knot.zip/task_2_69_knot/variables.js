var showhelp_var = "task_2_69_knot+_showhelp";
var completed_var = "task_2_69_knot+_completed";
var store_var = "task_2_69_knot+_store";