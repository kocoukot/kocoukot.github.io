var showhelp_var = "task_3_96_knot_showhelp";
var completed_var = "task_3_96_knot_completed";
var store_var = "task_3_96_knot_store";