var showhelp_var = "task_3_20_dnd+_showhelp";
var completed_var = "task_3_20_dnd+_completed";
var store_var = "task_3_20_dnd+_store";