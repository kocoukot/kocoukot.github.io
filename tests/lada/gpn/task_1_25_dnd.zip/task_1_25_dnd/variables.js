var showhelp_var = "task_1_25_dnd_showhelp";
var completed_var = "task_1_25_dnd_completed";
var store_var = "task_1_25_dnd_store";