var showhelp_var = "task_2_69_knot_showhelp";
var completed_var = "task_2_69_knot_completed";
var store_var = "task_2_69_knot_store";