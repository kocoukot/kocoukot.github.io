var showhelp_var = "task_1_25_dnd_showhelp_cards";
var completed_var = "task_1_25_dnd_completed_cards";
var store_var = "task_1_25_dnd_store_cards";