var showhelp_var = "task_1_25_dnd_cards_showhelp";
var completed_var = "task_1_25_dnd_cards_completed";
var store_var = "task_1_25_dnd_cards_store";