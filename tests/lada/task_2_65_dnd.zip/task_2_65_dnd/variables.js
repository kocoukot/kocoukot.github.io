var showhelp_var = "task_2_65_dnd+_showhelp";
var completed_var = "task_2_65_dnd+_completed";
var store_var = "task_2_65_dnd+_store";