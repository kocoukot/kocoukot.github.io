var showhelp_var = "task_2_65_dnd_showhelp";
var completed_var = "task_2_65_dnd_completed";
var store_var = "task_2_65_dnd_store";