var showhelp_var = "player_task_showhelp_player";
var completed_var = "player_task_completed_player";
var store_var = "player_task_store_player";