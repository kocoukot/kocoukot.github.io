var showhelp_var = "dnd_two_with_zoom_showhelp_102_107";
var completed_var = "dnd_two_with_zoom_completed_102_107";
var store_var = "dnd_two_with_zoom_store_102_107";