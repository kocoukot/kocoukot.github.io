var showhelp_var = "86-88_showhelp";
var completed_var = "86-88_completed";
var store_var = "86-88_store";