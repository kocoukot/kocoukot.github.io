var showhelp_var = "90-92_showhelp";
var completed_var = "90-92_completed";
var store_var = "90-92_store";